export const ApiUrl = "http://localhost:5000";
export const logdomain = "user_dev";
export const authurl = "";
export const unauthurl = "";