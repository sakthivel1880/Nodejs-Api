import React, { Component } from 'react'

export default class Footerthird extends Component {
    render() {
        return (
            <div>
            <div className="copy-right py-3">
                <div className="container">
                <p className="text-center text-white">© 2018 Electro Store. All rights reserved | Design by
                    <a href="http://localhost:3000/"> W3layouts.</a>
                </p>
                </div>
            </div>
            </div>

        )
    }
}
